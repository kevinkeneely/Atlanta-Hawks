import { useState } from "react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, Cell,
  ScatterChart, Scatter, ZAxis, ReferenceLine,
  LineChart, Line, CartesianGrid,
} from "recharts";

const RED = "#E03A3E";
const GOLD = "#C1A84F";
const DARK = "#0D1018";
const CARD = "#151922";
const BORDER = "#222736";
const TEXT = "#E8EAF2";
const MUTED = "#6B7490";
const TEAL = "#3BBFB0";
const BLUE = "#4A90D9";
const GREEN = "#6ECF8A";

const players = [
  {
    name: "Dyson Daniels",      age: 22, pos: "SG", g: 58, gs: 58, mp: 1937,
    per: 14.3, ts: .518, threepar: .143, ftr: .164,
    orbp: 6.9, drbp: 14.1, trbp: 10.5, astp: 25.0, stlp: 2.7, blkp: 1.1, tovp: 14.8, usgp: 16.0,
    ows: 1.5, dws: 2.4, ws: 3.9, ws48: .096, obpm: -1.5, dbpm: 1.4, bpm: -0.1, vorp: 0.9,
    epmOff: -0.6, epmDef: 2.3, epm: 1.8, ew: 6.3,
    efg: 50.7, rimp: 62.4, midp: 44.2, threepp: 12.9, ftp: 59.8,
    tier: "star", role: "Elite Defender / Playmaker"
  },
  {
    name: "Jalen Johnson",      age: 24, pos: "SF", g: 54, gs: 54, mp: 1901,
    per: 21.2, ts: .584, threepar: .266, ftr: .327,
    orbp: 4.6, drbp: 28.1, trbp: 16.2, astp: 34.7, stlp: 1.8, blkp: 1.3, tovp: 14.7, usgp: 27.3,
    ows: 2.8, dws: 2.7, ws: 5.6, ws48: .141, obpm: 3.0, dbpm: 1.3, bpm: 4.3, vorp: 3.0,
    epmOff: 1.6, epmDef: -0.0, epm: 1.6, ew: 6.0,
    efg: 54.0, rimp: 66.9, midp: 43.4, threepp: 34.3, ftp: 78.8,
    tier: "star", role: "Franchise Cornerstone", awards: "AS"
  },
  {
    name: "N. Alexander-Walker", age: 27, pos: "SG", g: 58, gs: 51, mp: 1925,
    per: 14.9, ts: .576, threepar: .524, ftr: .249,
    orbp: 1.9, drbp: 9.8, trbp: 5.8, astp: 16.4, stlp: 1.7, blkp: 1.5, tovp: 10.8, usgp: 24.2,
    ows: 1.3, dws: 1.7, ws: 3.0, ws48: .075, obpm: 0.4, dbpm: -0.9, bpm: -0.6, vorp: 0.7,
    epmOff: 0.9, epmDef: -0.2, epm: 0.7, ew: 4.9,
    efg: 52.8, rimp: 56.7, midp: 38.9, threepp: 37.3, ftp: 88.8,
    tier: "starter", role: "Starting SG / 3PT Shooter"
  },
  {
    name: "CJ McCollum",        age: 34, pos: "PG", g: 21, gs: 5, mp: 594,
    per: 15.9, ts: .553, threepar: .424, ftr: .231,
    orbp: 3.2, drbp: 9.3, trbp: 6.2, astp: 18.4, stlp: 1.5, blkp: 1.8, tovp: 9.7, usgp: 27.5,
    ows: 0.2, dws: 0.5, ws: 0.6, ws48: .052, obpm: 1.2, dbpm: -1.2, bpm: 0.0, vorp: 0.3,
    epmOff: 1.0, epmDef: -1.1, epm: -0.0, ew: 3.2,
    efg: 53.6, rimp: 60.9, midp: 46.0, threepp: 37.9, ftp: 78.0,
    tier: "starter", role: "Trade Acquisition (Jan)"
  },
  {
    name: "Onyeka Okongwu",     age: 25, pos: "C",  g: 55, gs: 44, mp: 1733,
    per: 15.9, ts: .591, threepar: .434, ftr: .226,
    orbp: 6.4, drbp: 20.4, trbp: 13.3, astp: 14.5, stlp: 1.6, blkp: 2.9, tovp: 12.3, usgp: 20.3,
    ows: 1.7, dws: 2.2, ws: 3.9, ws48: .109, obpm: -0.3, dbpm: 0.4, bpm: 0.1, vorp: 0.9,
    epmOff: -0.5, epmDef: 0.1, epm: -0.4, ew: 3.0,
    efg: 56.3, rimp: 64.1, midp: 44.6, threepp: 37.7, ftp: 78.2,
    tier: "starter", role: "Two-Way Center"
  },
  {
    name: "Jock Landale",       age: 30, pos: "C",  g: 9,  gs: 1,  mp: 182,
    per: 19.5, ts: .631, threepar: .420, ftr: .261,
    orbp: 13.4, drbp: 13.1, trbp: 13.3, astp: 11.1, stlp: 1.3, blkp: 3.5, tovp: 7.2, usgp: 19.0,
    ows: 0.5, dws: 0.2, ws: 0.6, ws48: .170, obpm: 3.0, dbpm: -0.4, bpm: 2.6, vorp: 0.2,
    epmOff: 1.4, epmDef: -1.9, epm: -0.5, ew: 2.0,
    efg: 58.4, rimp: 61.3, midp: 51.4, threepp: 39.9, ftp: 66.7,
    tier: "rotation", role: "Backup C"
  },
  {
    name: "Mouhamed Gueye",     age: 23, pos: "PF", g: 58, gs: 5,  mp: 931,
    per: 11.6, ts: .521, threepar: .426, ftr: .234,
    orbp: 8.2, drbp: 16.7, trbp: 12.4, astp: 7.6, stlp: 2.5, blkp: 2.9, tovp: 10.1, usgp: 12.9,
    ows: 0.4, dws: 1.3, ws: 1.7, ws48: .089, obpm: -3.2, dbpm: 1.0, bpm: -2.3, vorp: -0.1,
    epmOff: -2.1, epmDef: 1.1, epm: -1.0, ew: 1.3,
    efg: 50.2, rimp: 68.8, midp: 28.6, threepp: 28.0, ftp: 61.8,
    tier: "rotation", role: "Developmental Wing/Big"
  },
  {
    name: "Asa Newell",         age: 20, pos: "PF", g: 40, gs: 1,  mp: 445,
    per: 13.6, ts: .628, threepar: .463, ftr: .168,
    orbp: 8.8, drbp: 10.7, trbp: 9.8, astp: 6.3, stlp: 1.6, blkp: 2.6, tovp: 11.6, usgp: 16.9,
    ows: 0.5, dws: 0.4, ws: 0.9, ws48: .096, obpm: -1.4, dbpm: -0.7, bpm: -2.2, vorp: 0.0,
    epmOff: -1.0, epmDef: -0.1, epm: -1.1, ew: 0.6,
    efg: 62.8, rimp: 70.1, midp: 46.2, threepp: 39.1, ftp: 58.3,
    tier: "rotation", role: "2025 Draft Pick (Developmental)"
  },
  {
    name: "Jonathan Kuminga",   age: 23, pos: "PF", g: 22, gs: 1,  mp: 54,
    per: 30.1, ts: .797, threepar: .333, ftr: .714,
    orbp: 7.8, drbp: 24.2, trbp: 15.9, astp: 20.5, stlp: 2.6, blkp: 1.7, tovp: 15.3, usgp: 25.2,
    ows: 0.2, dws: 0.1, ws: 0.3, ws48: .294, obpm: 7.1, dbpm: 3.5, bpm: 10.6, vorp: 0.2,
    epmOff: -1.2, epmDef: -0.5, epm: -1.7, ew: 0.5,
    efg: 52.3, rimp: 62.0, midp: 38.1, threepp: 35.0, ftp: 75.3,
    tier: "rotation", role: "Trade Acquisition (Feb) — small sample"
  },
  {
    name: "Buddy Hield",        age: 33, pos: "SG", g: 45, gs: 0,  mp: 5,
    per: -16.4, ts: .000, threepar: 1.000, ftr: .000,
    orbp: 0.0, drbp: 0.0, trbp: 0.0, astp: 0.0, stlp: 0.0, blkp: 0.0, tovp: 50.0, usgp: 16.7,
    ows: 0.0, dws: 0.0, ws: 0.0, ws48: -.470, obpm: -17.5, dbpm: -8.7, bpm: -26.1, vorp: 0.0,
    epmOff: -1.2, epmDef: -0.9, epm: -2.1, ew: 0.5,
    efg: 54.3, rimp: 69.4, midp: 39.4, threepp: 34.2, ftp: 79.4,
    tier: "rotation", role: "3PT Specialist (ATL stats tiny — use D&T)",
    note: "BBRef ATL stats = 1 game; D&T covers full GSW+ATL season"
  },
  {
    name: "Keaton Wallace",     age: 26, pos: "PG", g: 43, gs: 2,  mp: 468,
    per: 10.7, ts: .529, threepar: .597, ftr: .097,
    orbp: 0.7, drbp: 10.5, trbp: 5.5, astp: 22.8, stlp: 2.1, blkp: 1.0, tovp: 12.8, usgp: 15.3,
    ows: 0.2, dws: 0.5, ws: 0.6, ws48: .067, obpm: -2.7, dbpm: 0.3, bpm: -2.4, vorp: -0.1,
    epmOff: -1.7, epmDef: -0.7, epm: -2.4, ew: 0.2,
    efg: 52.1, rimp: 55.6, midp: 38.8, threepp: 39.5, ftp: 75.0,
    tier: "bench", role: "Backup PG / 3&D"
  },
  {
    name: "Corey Kispert",      age: 26, pos: "SF", g: 21, gs: 6,  mp: 447,
    per: 12.7, ts: .601, threepar: .561, ftr: .228,
    orbp: 2.8, drbp: 10.9, trbp: 6.8, astp: 10.9, stlp: 0.6, blkp: 0.6, tovp: 10.0, usgp: 19.5,
    ows: 0.4, dws: 0.3, ws: 0.7, ws48: .072, obpm: -0.3, dbpm: -1.9, bpm: -2.1, vorp: 0.0,
    epmOff: -0.6, epmDef: -1.8, epm: -2.4, ew: 0.3,
    efg: 58.4, rimp: 64.4, midp: 50.0, threepp: 37.8, ftp: 83.6,
    tier: "rotation", role: "3&D Wing (Trade Acquisition)"
  },
  {
    name: "Zaccharie Risacher",  age: 20, pos: "SF", g: 47, gs: 45, mp: 1141,
    per: 10.5, ts: .530, threepar: .471, ftr: .153,
    orbp: 4.1, drbp: 12.2, trbp: 8.1, astp: 7.5, stlp: 1.7, blkp: 1.9, tovp: 8.8, usgp: 18.2,
    ows: -0.2, dws: 1.1, ws: 0.9, ws48: .037, obpm: -3.1, dbpm: -0.8, bpm: -4.0, vorp: -0.6,
    epmOff: -1.4, epmDef: -1.1, epm: -2.5, ew: 0.4,
    efg: 52.1, rimp: 57.6, midp: 41.9, threepp: 34.5, ftp: 56.5,
    tier: "rotation", role: "2024 #1 Pick (Year 2 — developing)"
  },
  {
    name: "Gabe Vincent",       age: 29, pos: "PG", g: 4,  gs: 0,  mp: 68,
    per: 9.8, ts: .423, threepar: .818, ftr: .045,
    orbp: 3.1, drbp: 3.2, trbp: 3.2, astp: 22.4, stlp: 2.8, blkp: 1.3, tovp: 4.3, usgp: 14.4,
    ows: 0.0, dws: 0.1, ws: 0.1, ws48: .060, obpm: -3.3, dbpm: 1.3, bpm: -2.0, vorp: 0.0,
    epmOff: -1.8, epmDef: -1.1, epm: -2.9, ew: 0.1,
    efg: 48.0, rimp: 62.5, midp: 21.7, threepp: 34.7, ftp: 90.0,
    tier: "bench", role: "Backup PG"
  },
];

const recentGames = [
  { date: "Jan 14", opp: "LAL", result: "L", pts: 116, oppPts: 141, home: false },
  { date: "Jan 16", opp: "POR", result: "L", pts: 101, oppPts: 117, home: false },
  { date: "Jan 18", opp: "BOS", result: "L", pts: 106, oppPts: 132, home: true  },
  { date: "Jan 19", opp: "MIL", result: "L", pts: 110, oppPts: 112, home: true  },
  { date: "Jan 22", opp: "MEM", result: "W", pts: 124, oppPts: 122, home: false },
  { date: "Jan 24", opp: "PHX", result: "W", pts: 110, oppPts: 103, home: true  },
  { date: "Jan 26", opp: "IND", result: "W", pts: 132, oppPts: 116, home: true  },
  { date: "Jan 29", opp: "BOS", result: "W", pts: 117, oppPts: 106, home: false },
  { date: "Jan 30", opp: "HOU", result: "L", pts: 86,  oppPts: 104, home: true  },
  { date: "Feb 1",  opp: "IND", result: "L", pts: 124, oppPts: 129, home: false },
  { date: "Feb 4",  opp: "MIA", result: "W", pts: 127, oppPts: 115, home: false },
  { date: "Feb 6",  opp: "UTA", result: "W", pts: 121, oppPts: 119, home: true  },
  { date: "Feb 8",  opp: "CHA", result: "L", pts: 119, oppPts: 126, home: true  },
  { date: "Feb 10", opp: "MIN", result: "L", pts: 116, oppPts: 138, home: false },
  { date: "Feb 12", opp: "CHA", result: "L", pts: 107, oppPts: 110, home: false },
  { date: "Feb 20", opp: "PHI", result: "W", pts: 117, oppPts: 107, home: false },
  { date: "Feb 21", opp: "MIA", result: "L", pts: 97,  oppPts: 128, home: true  },
  { date: "Feb 22", opp: "BKN", result: "W", pts: 115, oppPts: 104, home: true  },
  { date: "Feb 25", opp: "WAS", result: "W", pts: 119, oppPts: 98,  home: true  },
  { date: "Feb 27", opp: "WAS", result: "W", pts: 126, oppPts: 96,  home: true  },
];

const tierColors = { star: RED, starter: GOLD, rotation: BLUE, bench: MUTED };
const tierLabels  = { star: "Core", starter: "Starter", rotation: "Rotation", bench: "Bench" };

const TABS = ["Overview", "EPM", "Advanced", "Roster", "Scoring"];

const fmt = (v, dec = 1) => typeof v === "number" ? v.toFixed(dec) : v;

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#1a1f2e", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "10px 14px", fontSize: 12, fontFamily: "sans-serif" }}>
      <div style={{ color: MUTED, marginBottom: 6, fontWeight: 600 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || TEXT }}>{p.name}: {fmt(p.value, 2)}</div>
      ))}
    </div>
  );
};

export default function HawksDashboard() {
  const [tab, setTab] = useState("Overview");
  const [sortKey, setSortKey] = useState("epm");
  const [selectedPlayer, setSelectedPlayer] = useState(null);

  const last10 = recentGames.slice(-10);
  const last10W = last10.filter(g => g.result === "W").length;
  const winRunLine = recentGames.map((g, i) => {
    const w = recentGames.slice(0, i + 1).filter(x => x.result === "W").length;
    return { game: g.date, net: w - (i + 1 - w) };
  });

  const epmScatter = players.filter(p => p.mp > 50).map(p => ({
    name: p.name,
    x: p.epmOff,
    y: p.epmDef,
    z: p.mp / 30,
    tier: p.tier,
    epm: p.epm,
  }));

  const sorted = [...players].sort((a, b) => {
    const mult = ["tovp", "epmDef"].includes(sortKey) ? 1 : -1;
    return mult * (a[sortKey] - b[sortKey]);
  });

  const radarData = [
    { metric: "TS%",       ATL: Math.round(players[0].ts * 100 * 1.6),  Avg: 50 },
    { metric: "Playmaking",ATL: 72, Avg: 50 },
    { metric: "Defense",   ATL: 44, Avg: 50 },
    { metric: "Rebounding",ATL: 55, Avg: 50 },
    { metric: "Ball Care", ATL: 68, Avg: 50 },
    { metric: "3PT Vol",   ATL: 50, Avg: 50 },
  ];

  const teamWS = players.reduce((a, p) => a + (p.ws || 0), 0);
  const teamVORP = players.reduce((a, p) => a + (p.vorp || 0), 0);
  const teamEW = players.reduce((a, p) => a + (p.ew || 0), 0);

  return (
    <div style={{ fontFamily: "'Palatino Linotype', 'Book Antiqua', serif", background: DARK, minHeight: "100vh", color: TEXT }}>

      {/* ── HEADER ── */}
      <div style={{ background: "linear-gradient(160deg,#0a0d16 0%,#190810 60%,#0a0d16 100%)", borderBottom: `1px solid ${BORDER}`, padding: "22px 28px 16px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 5, color: GOLD, textTransform: "uppercase", marginBottom: 5 }}>
              2025–26 · Through Feb 28 · BBRef + Dunks & Threes EPM
            </div>
            <h1 style={{ margin: 0, fontSize: 26, fontWeight: 900, letterSpacing: -0.5 }}>
              ATLANTA <span style={{ color: RED }}>HAWKS</span>
            </h1>
            <div style={{ fontSize: 11, color: MUTED, marginTop: 2 }}>Post-deadline roster · Trae Young / Porzingis / Krejci / Kennard excluded</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 30, fontWeight: 900 }}>30–31</div>
            <div style={{ fontSize: 11, color: MUTED }}>9th East · Play-In Bubble</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 22, flexWrap: "wrap", borderTop: `1px solid ${BORDER}`, paddingTop: 12 }}>
          {[
            { l: "Team WS",   v: fmt(teamWS, 1), c: GREEN },
            { l: "Team VORP", v: fmt(teamVORP, 1), c: teamVORP > 0 ? GREEN : RED },
            { l: "Team EW",   v: fmt(teamEW, 1), c: GREEN },
            { l: "L10",       v: `${last10W}-${10-last10W}`, c: last10W >= 5 ? GREEN : RED },
            { l: "Top BPM",   v: "JJ +4.3", c: RED },
            { l: "Top EPM",   v: "DD +1.8", c: TEAL },
            { l: "Top WS",    v: "JJ 5.6", c: RED },
            { l: "Top VORP",  v: "JJ 3.0", c: RED },
          ].map(s => (
            <div key={s.l}>
              <div style={{ fontSize: 9, color: MUTED, textTransform: "uppercase", letterSpacing: 2.5 }}>{s.l}</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: s.c }}>{s.v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── NAV ── */}
      <div style={{ display: "flex", background: CARD, borderBottom: `1px solid ${BORDER}`, padding: "0 28px", overflowX: "auto" }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            background: "none", border: "none", cursor: "pointer", whiteSpace: "nowrap",
            padding: "12px 16px", color: tab === t ? RED : MUTED,
            fontSize: 11, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase",
            borderBottom: tab === t ? `2px solid ${RED}` : "2px solid transparent",
            transition: "all 0.15s"
          }}>{t}</button>
        ))}
      </div>

      <div style={{ padding: "22px 28px" }}>

        {/* ══════════════════════════════════ OVERVIEW ══════════════════════════════════ */}
        {tab === "Overview" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Team Identity</div>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Radar Profile</div>
              <ResponsiveContainer width="100%" height={210}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke={BORDER} />
                  <PolarAngleAxis dataKey="metric" tick={{ fill: MUTED, fontSize: 11, fontFamily: "sans-serif" }} />
                  <Radar name="ATL" dataKey="ATL" stroke={RED} fill={RED} fillOpacity={0.2} strokeWidth={2.5} />
                  <Radar name="Avg" dataKey="Avg" stroke={GOLD} fill="none" strokeDasharray="5 5" strokeWidth={1.5} />
                </RadarChart>
              </ResponsiveContainer>
              <div style={{ fontSize: 11, color: MUTED, textAlign: "center" }}>
                <span style={{ color: RED }}>▬ </span>Hawks &nbsp;&nbsp;
                <span style={{ color: GOLD }}>╌ </span>League Avg
              </div>
            </div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Win Shares by Player</div>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Season Contribution (WS)</div>
              <ResponsiveContainer width="100%" height={210}>
                <BarChart data={[...players].filter(p => p.ws > 0.2).sort((a,b) => b.ws - a.ws)} layout="vertical">
                  <XAxis type="number" tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} domain={[0, 6.5]} />
                  <YAxis type="category" dataKey="name" tick={{ fill: TEXT, fontSize: 10, fontFamily: "sans-serif" }} width={130} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="ws" name="Win Shares" radius={[0, 4, 4, 0]}>
                    {[...players].filter(p => p.ws > 0.2).sort((a,b) => b.ws - a.ws).map((p, i) => (
                      <Cell key={i} fill={tierColors[p.tier]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Recent Form</div>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Rolling Net W-L (Last 20 Games)</div>
              <ResponsiveContainer width="100%" height={140}>
                <LineChart data={winRunLine}>
                  <CartesianGrid stroke={BORDER} strokeDasharray="4 4" vertical={false} />
                  <XAxis dataKey="game" tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} interval={1} />
                  <YAxis tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} domain={[-8, 4]} />
                  <ReferenceLine y={0} stroke={MUTED} strokeDasharray="3 3" />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="net" name="Net (W-L)" stroke={RED} strokeWidth={2.5}
                    dot={({ cx, cy, payload }) => (
                      <circle key={payload.game} cx={cx} cy={cy} r={3} fill={payload.net >= 0 ? GREEN : RED} stroke="none" />
                    )} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 8 }}>Analyst Summary</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
                {[
                  { icon: "🌟", title: "Johnson is Legit", body: "WS/48 of .141, BPM of +4.3, and VORP of 3.0 — all top-15 in the league. Only player averaging 23+ pts, 10+ reb, 8+ ast. All-Star snub." },
                  { icon: "🛡️", title: "Daniels Anchors Defense", body: "EPM of +1.8 — team's highest. Defensive EPM of +2.3 (96th percentile). WS 3.9 despite minimal offensive load. The engine Atlanta needed." },
                  { icon: "⚠️", title: "Depth is a Problem", body: "Only 3 players with positive EPM. Kuminga (small sample) & Risacher (2nd-year struggles) haven't provided two-way lift yet. VORP: only JJ & Daniels matter." },
                ].map(s => (
                  <div key={s.title} style={{ background: DARK, borderRadius: 8, padding: 14, borderLeft: `3px solid ${GOLD}` }}>
                    <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8 }}>{s.icon} {s.title}</div>
                    <div style={{ fontSize: 11, color: MUTED, lineHeight: 1.75 }}>{s.body}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════ EPM TAB ══════════════════════════════════ */}
        {tab === "EPM" && (
          <div>
            <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Dunks & Threes</div>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Estimated Plus-Minus (EPM) — through Feb 28</div>
            <div style={{ fontSize: 11, color: MUTED, marginBottom: 20 }}>
              EPM = total value per 100 possessions. OFF = offensive contribution, DEF = defensive contribution.
              Bubble size = minutes played.
            </div>

            {/* Scatter: OFF vs DEF EPM */}
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 18 }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>Offensive vs Defensive EPM</div>
              <ResponsiveContainer width="100%" height={320}>
                <ScatterChart margin={{ top: 10, right: 30, left: 0, bottom: 10 }}>
                  <CartesianGrid stroke={BORDER} strokeDasharray="4 4" />
                  <XAxis dataKey="x" name="OFF EPM" type="number" domain={[-3, 3]}
                    tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }}
                    label={{ value: "Offensive EPM →", position: "insideBottom", fill: MUTED, fontSize: 10, fontFamily: "sans-serif", dy: 12 }} />
                  <YAxis dataKey="y" name="DEF EPM" type="number" domain={[-3, 3]}
                    tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }}
                    label={{ value: "Defensive EPM →", angle: -90, position: "insideLeft", fill: MUTED, fontSize: 10, fontFamily: "sans-serif", dx: -4 }} />
                  <ZAxis dataKey="z" range={[40, 400]} />
                  <ReferenceLine x={0} stroke={BORDER} strokeWidth={1.5} />
                  <ReferenceLine y={0} stroke={BORDER} strokeWidth={1.5} />
                  <Tooltip
                    cursor={{ strokeDasharray: "3 3" }}
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const d = payload[0]?.payload;
                      return (
                        <div style={{ background: "#1a1f2e", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "10px 14px", fontSize: 12, fontFamily: "sans-serif" }}>
                          <div style={{ fontWeight: 700, marginBottom: 6, color: tierColors[d.tier] }}>{d.name}</div>
                          <div>OFF EPM: <span style={{ color: d.x >= 0 ? GREEN : RED }}>{fmt(d.x, 1)}</span></div>
                          <div>DEF EPM: <span style={{ color: d.y >= 0 ? GREEN : RED }}>{fmt(d.y, 1)}</span></div>
                          <div>Total EPM: <span style={{ color: d.epm >= 0 ? GREEN : RED, fontWeight: 700 }}>{fmt(d.epm, 1)}</span></div>
                        </div>
                      );
                    }}
                  />
                  <Scatter data={epmScatter} fill={RED}>
                    {epmScatter.map((p, i) => (
                      <Cell key={i} fill={tierColors[p.tier]} fillOpacity={0.85} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
              {/* Quadrant labels */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 8, fontSize: 10, color: MUTED }}>
                <div style={{ textAlign: "left" }}>← Two-way defensive specialist (low off, high def)</div>
                <div style={{ textAlign: "right" }}>→ All-around positive contributor (top right)</div>
              </div>
              <div style={{ marginTop: 12, display: "flex", gap: 16, flexWrap: "wrap", fontSize: 11 }}>
                {Object.entries(tierColors).map(([k, c]) => (
                  <span key={k}><span style={{ color: c }}>●</span> {tierLabels[k]}</span>
                ))}
                <span style={{ color: MUTED }}>· Bubble = minutes played</span>
              </div>
            </div>

            {/* EPM ranked bar */}
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>EPM Rankings (Total)</div>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={[...players].filter(p => p.mp > 50).sort((a,b) => b.epm - a.epm)} layout="vertical">
                  <XAxis type="number" domain={[-3.5, 2.5]} tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} />
                  <YAxis type="category" dataKey="name" tick={{ fill: TEXT, fontSize: 11, fontFamily: "sans-serif" }} width={140} />
                  <ReferenceLine x={0} stroke={GOLD} strokeWidth={1.5} strokeDasharray="3 3" />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="epm" name="EPM" radius={[0, 4, 4, 0]}>
                    {[...players].filter(p => p.mp > 50).sort((a,b) => b.epm - a.epm).map((p, i) => (
                      <Cell key={i} fill={p.epm >= 0 ? GREEN : RED} fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div style={{ marginTop: 12, padding: "10px 14px", background: DARK, borderRadius: 8, fontSize: 12, color: MUTED, lineHeight: 1.8 }}>
                <strong style={{ color: TEXT }}>Key insight:</strong> Only Dyson Daniels (+1.8), Jalen Johnson (+1.6) and Nickeil Alexander-Walker (+0.7) post positive EPM.
                Every other rotation player is a net negative. This three-man reliance is Atlanta's biggest vulnerability.
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════ ADVANCED TAB ══════════════════════════════════ */}
        {tab === "Advanced" && (
          <div>
            <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Basketball Reference</div>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Advanced Stats — Full Table</div>
            <div style={{ fontSize: 11, color: MUTED, marginBottom: 16 }}>
              Click column headers to sort. Data through Feb 28 (61 team games).
            </div>

            {/* BPM bar */}
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Box Plus/Minus (BPM) — qualifiers only (&gt;100 min)</div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={[...players].filter(p => p.mp >= 100).sort((a,b) => b.bpm - a.bpm)} layout="vertical">
                  <XAxis type="number" domain={[-7, 6]} tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} />
                  <YAxis type="category" dataKey="name" tick={{ fill: TEXT, fontSize: 10, fontFamily: "sans-serif" }} width={140} />
                  <ReferenceLine x={0} stroke={GOLD} strokeDasharray="3 3" />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="bpm" name="BPM" radius={[0, 4, 4, 0]}>
                    {[...players].filter(p => p.mp >= 100).sort((a,b) => b.bpm - a.bpm).map((p, i) => (
                      <Cell key={i} fill={p.bpm >= 0 ? GREEN : RED} fillOpacity={0.8} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Full stat table */}
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, overflow: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11, fontFamily: "sans-serif" }}>
                <thead>
                  <tr style={{ background: DARK, borderBottom: `1px solid ${BORDER}` }}>
                    {[
                      ["name","Player"], ["pos","Pos"], ["g","G"], ["mp","MP"],
                      ["per","PER"], ["ts","TS%"], ["ws","WS"], ["ws48","WS/48"],
                      ["obpm","OBPM"], ["dbpm","DBPM"], ["bpm","BPM"], ["vorp","VORP"],
                    ].map(([k, label]) => (
                      <th key={k} onClick={() => setSortKey(k)} style={{
                        padding: "10px 10px", textAlign: k === "name" ? "left" : "right",
                        fontSize: 9, color: sortKey === k ? GOLD : MUTED,
                        letterSpacing: 1.5, textTransform: "uppercase", fontWeight: 700,
                        cursor: "pointer", userSelect: "none", whiteSpace: "nowrap"
                      }}>{label} {sortKey === k ? "▼" : ""}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((p, i) => (
                    <tr key={p.name}
                      onClick={() => setSelectedPlayer(selectedPlayer === p.name ? null : p.name)}
                      style={{
                        background: selectedPlayer === p.name ? "#1c2133" : i % 2 === 0 ? CARD : DARK,
                        borderBottom: `1px solid ${BORDER}`, cursor: "pointer",
                        borderLeft: selectedPlayer === p.name ? `3px solid ${tierColors[p.tier]}` : "3px solid transparent"
                      }}>
                      <td style={{ padding: "8px 10px", fontWeight: 600, color: tierColors[p.tier], whiteSpace: "nowrap" }}>
                        {p.name} {p.awards ? <span style={{ fontSize: 9, background: GOLD, color: DARK, borderRadius: 3, padding: "1px 4px", marginLeft: 4 }}>{p.awards}</span> : ""}
                      </td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: MUTED }}>{p.pos}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right" }}>{p.g}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right" }}>{p.mp}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.per >= 15 ? GREEN : TEXT }}>{fmt(p.per)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.ts >= .560 ? GREEN : TEXT }}>{fmt(p.ts * 100, 1)}%</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.ws >= 2 ? GREEN : TEXT }}>{fmt(p.ws)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.ws48 >= .100 ? GREEN : TEXT }}>{fmt(p.ws48, 3)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.obpm >= 0 ? GREEN : RED }}>{fmt(p.obpm)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.dbpm >= 0 ? GREEN : RED }}>{fmt(p.dbpm)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.bpm >= 0 ? GREEN : RED, fontWeight: 700 }}>{fmt(p.bpm)}</td>
                      <td style={{ padding: "8px 8px", textAlign: "right", color: p.vorp >= 1 ? GREEN : p.vorp >= 0 ? TEXT : RED, fontWeight: p.vorp >= 1 ? 700 : 400 }}>{fmt(p.vorp)}</td>
                    </tr>
                  ))}
                  <tr style={{ background: "#1a1030", borderTop: `2px solid ${BORDER}` }}>
                    <td colSpan={7} style={{ padding: "8px 10px", fontWeight: 700, fontSize: 11, color: GOLD }}>Team Totals</td>
                    <td style={{ padding: "8px 8px", textAlign: "right", color: GOLD }}>.098</td>
                    <td style={{ padding: "8px 8px", textAlign: "right", color: GREEN }}>−0.3</td>
                    <td style={{ padding: "8px 8px", textAlign: "right", color: GREEN }}>0.1</td>
                    <td style={{ padding: "8px 8px", textAlign: "right", fontWeight: 700, color: TEXT }}>−0.2</td>
                    <td style={{ padding: "8px 8px", textAlign: "right", fontWeight: 700, color: GREEN }}>6.7</td>
                  </tr>
                </tbody>
              </table>
              <div style={{ padding: "10px 14px", fontSize: 10, color: MUTED }}>
                Source: Basketball-Reference.com · Generated Mar 1, 2026 · Click any row to highlight · Click headers to sort
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════ ROSTER TAB ══════════════════════════════════ */}
        {tab === "Roster" && (
          <div>
            <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Current Roster</div>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 18 }}>Player Cards with EPM + Advanced</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: 12 }}>
              {[...players].sort((a,b) => b.epm - a.epm).map(p => (
                <div key={p.name}
                  onClick={() => setSelectedPlayer(selectedPlayer === p.name ? null : p.name)}
                  style={{
                    background: selectedPlayer === p.name ? "#1c2133" : CARD,
                    border: `1px solid ${selectedPlayer === p.name ? tierColors[p.tier] : BORDER}`,
                    borderLeft: `3px solid ${tierColors[p.tier]}`,
                    borderRadius: 10, padding: 14, cursor: "pointer", transition: "all 0.18s"
                  }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: tierColors[p.tier] }}>{p.name}</div>
                      <div style={{ fontSize: 10, color: MUTED }}>{p.pos} · {p.role}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 16, fontWeight: 900, color: p.epm >= 0 ? GREEN : RED }}>{p.epm >= 0 ? "+" : ""}{fmt(p.epm, 1)}</div>
                      <div style={{ fontSize: 9, color: MUTED }}>EPM</div>
                    </div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, textAlign: "center" }}>
                    {[
                      { l: "WS", v: fmt(p.ws), c: p.ws >= 2 ? GREEN : TEXT },
                      { l: "BPM", v: fmt(p.bpm), c: p.bpm >= 0 ? GREEN : RED },
                      { l: "VORP", v: fmt(p.vorp), c: p.vorp > 0 ? GREEN : RED },
                      { l: "TS%", v: `${fmt(p.ts*100,0)}%`, c: p.ts >= .56 ? GREEN : TEXT },
                    ].map(s => (
                      <div key={s.l} style={{ background: DARK, borderRadius: 6, padding: "7px 4px" }}>
                        <div style={{ fontSize: 14, fontWeight: 800, color: s.c }}>{s.v}</div>
                        <div style={{ fontSize: 8, color: MUTED, textTransform: "uppercase", letterSpacing: 0.5 }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                  {selectedPlayer === p.name && (
                    <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${BORDER}`, fontSize: 11, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                      {[
                        ["OFF EPM", `${p.epmOff >= 0 ? "+" : ""}${fmt(p.epmOff,1)}`],
                        ["DEF EPM", `${p.epmDef >= 0 ? "+" : ""}${fmt(p.epmDef,1)}`],
                        ["USG%", `${fmt(p.usgp,1)}%`],
                        ["TOV%", `${fmt(p.tovp,1)}%`],
                        ["STL%", `${fmt(p.stlp,1)}%`],
                        ["BLK%", `${fmt(p.blkp,1)}%`],
                        ["AST%", `${fmt(p.astp,1)}%`],
                        ["Games", p.g],
                      ].map(([l, v]) => (
                        <div key={l} style={{ display: "flex", justifyContent: "space-between", color: MUTED }}>
                          <span>{l}:</span><span style={{ color: TEXT, fontWeight: 600 }}>{v}</span>
                        </div>
                      ))}
                      {p.note && <div style={{ gridColumn: "1/-1", color: GOLD, fontSize: 10, marginTop: 4 }}>⚠️ {p.note}</div>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════ SCORING TAB ══════════════════════════════════ */}
        {tab === "Scoring" && (
          <div>
            <div style={{ fontSize: 10, color: GOLD, letterSpacing: 3, textTransform: "uppercase", marginBottom: 3 }}>Shot Quality & Efficiency</div>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 18 }}>Shooting Profile — Rim / Mid / 3PT / TS%</div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>True Shooting % by Player</div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={[...players].filter(p => p.mp > 100).sort((a,b) => b.ts - a.ts)} layout="vertical">
                  <XAxis type="number" domain={[0.42, 0.85]} tickFormatter={v => `${(v*100).toFixed(0)}%`}
                    tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} />
                  <YAxis type="category" dataKey="name" tick={{ fill: TEXT, fontSize: 10, fontFamily: "sans-serif" }} width={140} />
                  <ReferenceLine x={0.578} stroke={GOLD} strokeDasharray="3 3" label={{ value: "Team avg .578", fill: GOLD, fontSize: 9, fontFamily: "sans-serif" }} />
                  <Tooltip formatter={(v) => `${(v*100).toFixed(1)}%`} contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="ts" name="TS%" radius={[0, 4, 4, 0]}>
                    {[...players].filter(p => p.mp > 100).sort((a,b) => b.ts - a.ts).map((p, i) => (
                      <Cell key={i} fill={p.ts >= 0.578 ? GREEN : p.ts >= 0.54 ? GOLD : RED} fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Shot Location Mix — Rim vs Mid vs 3PT%</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
                {[...players].filter(p => p.mp > 200).map(p => (
                  <div key={p.name} style={{ background: DARK, borderRadius: 8, padding: 12 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: tierColors[p.tier], marginBottom: 8 }}>{p.name}</div>
                    {[
                      { l: "Rim", v: p.rimp, c: GREEN },
                      { l: "Mid", v: p.midp, c: GOLD },
                      { l: "3PT", v: p.threepp, c: BLUE },
                    ].map(s => (
                      <div key={s.l} style={{ marginBottom: 6 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, marginBottom: 3 }}>
                          <span style={{ color: MUTED }}>{s.l}%</span>
                          <span style={{ color: s.c, fontWeight: 600 }}>{fmt(s.v, 1)}%</span>
                        </div>
                        <div style={{ background: BORDER, borderRadius: 3, height: 5 }}>
                          <div style={{ width: `${Math.min(s.v, 100)}%`, height: "100%", borderRadius: 3, background: s.c, opacity: 0.8 }} />
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>

            {/* Scoring game log */}
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>ATL vs Opponent Pts — Last 20 Games</div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={recentGames.map(g => ({ game: `${g.date} ${g.opp}`, ATL: g.pts, OPP: g.oppPts, result: g.result }))} barGap={2}>
                  <CartesianGrid stroke={BORDER} strokeDasharray="4 4" vertical={false} />
                  <XAxis dataKey="game" tick={{ fill: MUTED, fontSize: 9, fontFamily: "sans-serif" }} interval={0} angle={-35} textAnchor="end" height={50} />
                  <YAxis domain={[75, 150]} tick={{ fill: MUTED, fontSize: 10, fontFamily: "sans-serif" }} />
                  <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="ATL" fill={GREEN} fillOpacity={0.8} name="ATL" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="OPP" fill={RED}   fillOpacity={0.7} name="OPP" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

      </div>

      <div style={{ textAlign: "center", fontSize: 10, color: MUTED, padding: "8px 28px 24px" }}>
        Sources: Basketball-Reference.com (BBRef advanced, generated Mar 1 2026) · Dunks &amp; Threes EPM (through Feb 28) · SportRadar game data
      </div>
    </div>
  );
}